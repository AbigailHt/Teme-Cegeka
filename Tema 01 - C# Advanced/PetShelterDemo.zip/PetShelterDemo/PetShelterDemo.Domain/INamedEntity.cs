﻿namespace PetShelterDemo.Domain
{
    public interface INamedEntity
    {
        string Name { get; }
    }
}
