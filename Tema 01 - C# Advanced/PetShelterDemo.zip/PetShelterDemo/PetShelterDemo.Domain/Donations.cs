﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetShelterDemo.Domain
{
    public class Donations
    {
        public float EUR { get; set; }
        public float RON { get; set; }
        public float DOLLAR { get; set; } 
    }
}
